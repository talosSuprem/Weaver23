package fr.sankai.crypters.Model

class Chatlist {
    var id: String? = null

    constructor(id: String?) {
        this.id = id
    }

    constructor() {}
}