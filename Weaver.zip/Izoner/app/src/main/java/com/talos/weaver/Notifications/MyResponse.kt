package fr.sankai.crypters.Notifications

class MyResponse {
    var success = 0
}