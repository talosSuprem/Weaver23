package com.talos.weaver;

import android.app.Activity;

public class PostActivity extends Activity {
}
