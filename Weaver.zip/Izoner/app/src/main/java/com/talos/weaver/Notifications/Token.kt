package fr.sankai.crypters.Notifications

class Token {
    var token: String? = null

    constructor(token: String?) {
        this.token = token
    }

    constructor() {}
}