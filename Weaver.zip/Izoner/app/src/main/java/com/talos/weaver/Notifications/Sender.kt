package fr.sankai.crypters.Notifications

class Sender(var data: Data, var to: String)