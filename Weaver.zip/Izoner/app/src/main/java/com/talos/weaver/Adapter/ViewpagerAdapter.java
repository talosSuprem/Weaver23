package com.talos.weaver.Adapter;

public class ViewpagerAdapter {

}
