package com.talos.weaver.NotificationsSocial;

public class Response {

    private String success;
}
