package com.talos.weaver.activitybook;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.talos.weaver.R;

public class QalamAdminActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qalam_admin);
    }
}