package com.talos.weaver;

public class Constants {

    public static final long MAX_BYTES_PDF = 50000000;
    public static final int MAX_COIN_GEN1 = 1000000;
}
